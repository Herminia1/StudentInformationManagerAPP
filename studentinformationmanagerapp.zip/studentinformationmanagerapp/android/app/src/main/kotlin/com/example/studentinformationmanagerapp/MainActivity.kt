package com.example.studentinformationmanagerapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
